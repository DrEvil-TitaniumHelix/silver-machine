"""The shared Session protocol on JSPI stacks, with no Python threads.

Only queue waits and worker scheduling change. Decisions, step validation,
AI checks, errors and cancellation stay in sm.engine.Session.
"""
from collections import deque
from queue import Empty
from sm.engine import Session as NativeSession

_targets = {}


def run_worker(token):
    """One owned dispatcher proxy; per-session callbacks stay in Python."""
    _targets.pop(token)()


class Queue:
    def __init__(self):
        self.items = deque()
        self.token = str(id(self))

    def put(self, value):
        from sm_browser_bridge import wake
        self.items.append(value)
        wake(self.token)

    def get(self, timeout=None):
        from pyodide.ffi import run_sync
        from sm_browser_bridge import wait
        if not self.items and not run_sync(wait(self.token, timeout)):
            raise Empty
        return self.items.popleft()


class Worker:
    def __init__(self, target, daemon=True): self.target = target

    def start(self):
        from sm_browser_bridge import spawn
        token = str(id(self))
        _targets[token] = self.target
        self.task = spawn(token)

    def join(self, timeout=None):
        from pyodide.ffi import run_sync
        from sm_browser_bridge import join
        if not run_sync(join(self.task, timeout)):
            raise TimeoutError('Browser game stack did not close')


class Session(NativeSession):
    queue_factory = Queue
    worker_factory = Worker


def install():
    """Install before importing UI modules that keep a Session reference."""
    import sm.engine
    sm.engine.Session = Session

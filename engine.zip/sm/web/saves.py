from io import BytesIO
import json
from pathlib import Path, PurePosixPath
import re
import shutil
from zipfile import ZipFile, ZIP_DEFLATED, BadZipFile

LIMIT = 32 * 1024 * 1024
NATIVE = re.compile(r'(?:SAVGAM[A-Z]\.DAT|CHRDAT[A-Z][1-8]\.(?:SAV|STF|SFX)|VAULT\.DAT)\Z')
CHARACTER = re.compile(r'[^<>:"/\\|?*\x00-\x1f]{1,40}\.(?:WHO|STF|SFX)\Z', re.I)


def entries(raw, *, limit=LIMIT, count=2048):
    if len(raw) > limit: raise ValueError('Save file is too large')
    with ZipFile(BytesIO(raw)) as archive:
        infos = archive.infolist()
        if len(infos) > count or sum(x.file_size for x in infos) > limit:
            raise ValueError('Save expands beyond the size limit')
        names = [x.filename for x in infos]
        if len(set(names)) != len(names): raise ValueError('Duplicate save entries')
        for info in infos:
            parts = PurePosixPath(info.filename).parts
            if (not parts or info.is_dir() or '\\' in info.filename or ':' in info.filename
                    or info.filename.startswith('/') or '..' in parts or '.' in parts
                    or info.flag_bits & 1 or (info.external_attr >> 16) & 0o170000 == 0o120000):
                raise ValueError('Invalid save entry path')
        return {name: archive.read(name) for name in names}


def validate(files):
    from sm.titles.ssb import save
    from sm.ui.plus import validate as preferences
    if json.loads(files.get('format.json', b'{}')) != {'format': 1}:
        raise ValueError('Not a SilverMachine browser save')
    slots = {}
    for name, raw in files.items():
        parts = name.split('/')
        if name == 'format.json': continue
        if name == 'config/dqk-intake.json':
            data = json.loads(raw)
            if (not isinstance(data, dict) or set(data) != {'folder'}
                    or not isinstance(data['folder'], str) or len(data['folder']) > 4096 or '\0' in data['folder']):
                raise ValueError('Invalid Dark Queen folder preference')
        elif name == 'config/plus.json':
            data = json.loads(raw)
            preferences(data.get('options', {}))
            if not isinstance(data.get('manual_bodies', {}), dict): raise ValueError('Invalid icon preferences')
        elif re.fullmatch(r'config/bug-reports/bug-[\w-]+\.json', name):
            if not isinstance(json.loads(raw), dict): raise ValueError('Invalid local report')
        elif re.fullmatch(r'saves/journal-(?:resume|[A-Z])\.json', name):
            data = json.loads(raw)
            if not isinstance(data.get('history'), list) or not isinstance(data.get('entries'), dict):
                raise ValueError('Invalid saved journal')
        elif name == 'saves/autosave.zip':
            native = entries(raw, count=32)
            if not native.keys() <= {f'CHRDATA{i}.{ext}' for i in range(1,9) for ext in ('SAV','STF','SFX')} | {'SAVGAMA.DAT','VAULT.DAT'}:
                raise ValueError('Invalid resume save')
            save._load(native.get, 'A')
        elif len(parts) == 3 and parts[0] == 'saves' and re.fullmatch('[A-Z]', parts[1]) and NATIVE.fullmatch(parts[2]):
            slot = parts[1]
            if parts[2] not in {f'CHRDAT{slot}{i}.{ext}' for i in range(1,9) for ext in ('SAV','STF','SFX')} | {f'SAVGAM{slot}.DAT','VAULT.DAT'}:
                raise ValueError('Save entry belongs to another slot')
            slots.setdefault(slot, {})[parts[2]] = raw
        elif len(parts) == 2 and parts[0] == 'saves' and CHARACTER.fullmatch(parts[1]):
            if parts[1].upper().endswith('.WHO') and len(raw) != 439: raise ValueError('Invalid character record')
            if parts[1].upper().endswith('.STF') and len(raw) % 67: raise ValueError('Invalid character inventory')
            if parts[1].upper().endswith('.SFX') and len(raw) % 9: raise ValueError('Invalid character effects')
        else: raise ValueError('Unexpected browser save entry')
    for slot, native in slots.items(): save._load(native.get, slot)
    return files


def pack(saves, config):
    files = {'format.json': b'{"format":1}'}
    for name, root in [('saves', Path(saves)), ('config', Path(config))]:
        if root.exists():
            for path in sorted(root.rglob('*')):
                if path.is_file() and not any(part.startswith('.') for part in path.relative_to(root).parts):
                    files[name+'/'+path.relative_to(root).as_posix()] = path.read_bytes()
    validate(files)
    stream = BytesIO()
    with ZipFile(stream, 'w', compression=ZIP_DEFLATED) as archive:
        for name, raw in sorted(files.items()):
            from zipfile import ZipInfo
            info = ZipInfo(name, date_time=(2020,1,1,0,0,0)); info.compress_type = ZIP_DEFLATED
            archive.writestr(info, raw)
    return stream.getvalue()


def restore(raw, saves, config):
    files = validate(entries(raw))
    inputs = {'saves': Path(saves), 'config': Path(config)}
    if any(path.is_symlink() for path in inputs.values()): raise ValueError('Save roots cannot be symlinks')
    roots = {name:path.resolve() for name,path in inputs.items()}
    if (any(root == Path(root.anchor) for root in roots.values())
            or roots['saves'].is_relative_to(roots['config']) or roots['config'].is_relative_to(roots['saves'])):
        raise ValueError('Save roots must be distinct bounded directories')
    before = {name: {p.relative_to(root):p.read_bytes() for p in root.rglob('*') if p.is_file()}
              for name,root in roots.items()}
    try:
        for root in roots.values():
            if root.exists(): shutil.rmtree(root)
            root.mkdir(parents=True)
        for name, data in files.items():
            if name == 'format.json': continue
            prefix, relative = name.split('/',1)
            target = roots[prefix]/relative
            if not target.resolve().is_relative_to(roots[prefix]): raise ValueError('Invalid restore destination')
            target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(data)
    except BaseException:
        for name,root in roots.items():
            if root.exists(): shutil.rmtree(root)
            root.mkdir(parents=True)
            for relative,data in before[name].items():
                target = root/relative; target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(data)
        raise

"""Worker RPC over the existing HTTP handlers and controller, without sockets."""
from contextlib import nullcontext
from email.message import Message
import hashlib
from io import BytesIO
import json
from pathlib import Path
from urllib.parse import urlsplit
import uuid

from sm.titles import ssb
from sm.titles.ssb import intake
from sm.titles.ssb.ui import screen
from sm.ui import web
from sm.ui.plus import Settings

GETS = frozenset(('/version', '/palette', '/decision', '/layout', '/frame',
                  '/preferences', '/speed', '/plus/data', '/journal'))
POSTS = frozenset(('/key', '/preferences', '/speed', '/journal/note', '/plus/bug'))


class LocalHandler(web.Handler):
    def __init__(self, server, path, method, body, build):
        self.server, self.path = server, path
        self.headers = Message()
        self.headers['X-SM-Build'] = build
        self.headers['Content-Type'] = 'application/json'
        self.headers['Content-Length'] = str(len(body.encode()))
        self.rfile = BytesIO(body.encode())
        self.response = None
        allowed = GETS if method == 'GET' else POSTS if method == 'POST' else ()
        if urlsplit(path).path not in allowed:
            self.send_error(404, 'Unknown browser operation')
        elif method == 'GET': self.get()
        else: self.do_POST()

    def local_request(self): return True  # In-process worker RPC, not an HTTP endpoint.

    def reply(self, body, kind, *, frame_hash=None, status=200):
        self.response = dict(status=status, kind=kind, body=body)

    def send_error(self, status, message=None): self.json(dict(error=message), status=status)


class Application(web.Server):
    def __init__(self, build, book=None):
        # Deliberately do not call the HTTPServer constructor or bind a socket.
        self.profile, self.screen, self.intake = ssb, screen, intake
        self.plus = Settings(intake.config_path().with_name('plus.json'))
        self.controller = self.assets = None
        self.save_root, self.presentation = screen.SAVE_ROOT, True
        self.state_lock = self.log_lock = nullcontext()
        self.log_path = None
        self.logged_decision = None
        self.stopping = False
        self.instance = uuid.uuid4().hex
        self.book = book or dict(available=False, mapped=False)
        self.observations = []
        web.BUILD_ID = build
        self.build = build

    def attach(self, session):
        super().attach(session)
        book = dict(self.book)
        self.controller.journal.book.info = lambda: book

    def start(self, resume=False):
        from sm.engine import Session
        intake.require_folder()
        if self.controller: self.controller.session.close()
        session = screen.load_autosave(self.save_root) if resume else Session(
            profile=ssb, slot=None, engines=True, directory=self.save_root, timeout=30)
        self.attach(session)
        return dict(edition=intake._active['version'], decision=self.metadata())

    def preferences(self):
        result = super().preferences()
        # Desktop paths have no meaning in the browser's private filesystem.
        result['supported'] = [k for k in result['supported'] if k not in ('mods_folder', 'vga_frame')]
        result['look_note'] = 'VGA uses this copy’s frame and font. Desktop mod folders and other-title skins are not loaded by this demo.'
        return result

    def set_preferences(self, values):
        if set(values) & {'mods_folder', 'vga_frame'}:
            raise ValueError('Desktop mod folders and other-title skins are unavailable in this demo')
        return super().set_preferences(values)

    def log_decision(self):
        super().log_decision()
        value = self.metadata()
        if not self.observations or self.observations[-1] != value:
            self.observations.append(value)

    def metadata(self):
        if self.controller is None: return None
        session = self.controller.session
        d = session.decision
        return dict(kind=d['kind'], i=d['i'], hash=d['hash'], party=len(session.game.s.party)) if d else None

    def interruptible(self): return bool(self.controller and self.controller.rest_active)

    def request(self, path, method='GET', body='', build=None):
        handler = LocalHandler(self, path, method, body, build or self.build)
        if handler.response is None: raise RuntimeError('No RPC response')
        response = handler.response
        response['body'] = (json.loads(response['body']) if response['kind'].startswith('application/json')
                            else list(response['body']))
        return json.dumps(response)

    def checkpoint(self):
        if self.controller:
            self.controller.autosave()
            self.controller.journal.save('resume')
        from sm.web.saves import pack
        return pack(self.save_root, intake.config_path().parent)

    def info(self):
        return json.dumps(dict(decision=self.metadata(),
            slots=screen.available_slots(self.save_root),
            resume=(self.save_root/'autosave.zip').is_file(),
            observations=self.observations))

    def close(self):
        if self.controller: self.controller.session.close()

    def server_close(self): self.close()

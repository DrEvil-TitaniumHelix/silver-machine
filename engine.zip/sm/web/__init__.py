

def test():
    from sm.web._spike_test import test as spike
    from sm.web._saves_test import test as saves
    spike()
    saves()
